'use client';
import { useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import {
  DEFAULT_CENTER,
  SRI_LANKA_VIEW_BOUNDS,
  MAPBOX_STYLES,
  riskColors,
  buildPopupHTML,
  fetchVisibleZones,
  zonesToFeatureCollection
} from '../mapData';

mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;

function fitToSriLanka(map, isSmallScreen) {
  map.fitBounds(SRI_LANKA_VIEW_BOUNDS, {
    padding: isSmallScreen
      ? { top: 36, right: 20, bottom: 36, left: 20 }
      : { top: 48, right: 48, bottom: 48, left: 48 },
    duration: 0
  });

  map.setMinZoom(map.getZoom());
}

export default function AffectedMapPage() {
  const router = useRouter();
  const mapContainerRef = useRef(null);
  const mapRef = useRef(null);

  useEffect(() => {
    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: MAPBOX_STYLES.streets,
      center: DEFAULT_CENTER,
      zoom: 3.5,
      minZoom: 1
    });
    mapRef.current = map;

    const mediaQuery = window.matchMedia('(max-width: 900px)');
    const handleResize = () => {
      map.resize();
      fitToSriLanka(map, mediaQuery.matches);
    };

    map.on('load', async () => {
      fitToSriLanka(map, mediaQuery.matches);

      const visibleZones = await fetchVisibleZones();
      const floodZones = zonesToFeatureCollection(visibleZones);

      map.addSource('flood-zones', {
        type: 'geojson',
        data: floodZones
      });

      map.addLayer({
        id: 'flood-zones-fill',
        type: 'fill',
        source: 'flood-zones',
        paint: {
          'fill-color': [
            'match', ['get', 'risk_level'],
            'low', riskColors.low,
            'medium', riskColors.medium,
            'high', riskColors.high,
            'critical', riskColors.critical,
            '#cccccc'
          ],
          'fill-opacity': 0.45
        }
      });

      map.addLayer({
        id: 'flood-zones-outline',
        type: 'line',
        source: 'flood-zones',
        paint: {
          'line-color': [
            'match', ['get', 'risk_level'],
            'low', riskColors.low,
            'medium', riskColors.medium,
            'high', riskColors.high,
            'critical', riskColors.critical,
            '#cccccc'
          ],
          'line-width': 2
        }
      });

      map.on('click', 'flood-zones-fill', (e) => {
        const features = map.queryRenderedFeatures(e.point, {
          layers: ['flood-zones-fill']
        });
        if (!features.length) return;

        const priority = { critical: 4, high: 3, medium: 2, low: 1 };
        const mostCritical = features.reduce((top, cur) =>
          (priority[cur.properties.risk_level] || 0) >
          (priority[top.properties.risk_level] || 0) ? cur : top
        );

        new mapboxgl.Popup({ maxWidth: '280px' })
          .setLngLat(e.lngLat)
          .setHTML(buildPopupHTML(mostCritical.properties, features.length))
          .addTo(map);
      });

      map.on('mouseenter', 'flood-zones-fill', () => {
        map.getCanvas().style.cursor = 'pointer';
      });
      map.on('mouseleave', 'flood-zones-fill', () => {
        map.getCanvas().style.cursor = '';
      });
    });

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      map.remove();
      mapRef.current = null;
    };
  }, []);

  return (
    <div style={{ width: '100%', height: '100vh', display: 'flex', flexDirection: 'column', background: '#F5F7FA' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, padding: '12px 14px', borderBottom: '1px solid #E5E7EB', background: '#FFFFFF' }}>
        <button
          type="button"
          onClick={() => router.push('/map')}
          style={{
            border: '1px solid #E5E7EB',
            background: '#FFFFFF',
            color: '#1F2937',
            borderRadius: 10,
            padding: '8px 12px',
            fontSize: 14,
            cursor: 'pointer'
          }}
        >
          Back to 4 Maps
        </button>
        <button
          type="button"
          onClick={() => {
            const map = mapRef.current;
            if (!map) return;
            fitToSriLanka(map, window.matchMedia('(max-width: 900px)').matches);
          }}
          style={{
            border: '1px solid #E5E7EB',
            background: '#FFFFFF',
            color: '#1F2937',
            borderRadius: 10,
            padding: '8px 12px',
            fontSize: 14,
            cursor: 'pointer'
          }}
        >
          Reset View
        </button>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#1F2937' }}>Affected Area Map</div>
          <div style={{ fontSize: 13, color: '#6B7280' }}>Full-country flood zone view</div>
        </div>
      </div>
      <div ref={mapContainerRef} style={{ flex: 1, minHeight: 0 }} />
    </div>
  );
}
